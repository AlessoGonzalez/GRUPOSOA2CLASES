package com.mycompany.quinto;

import java.util.List;

/**
 *
 * @author jespi
 */
public interface CrudRepository<T> {
    
    List<T> getAll();
    boolean create(T entity);
    boolean update(T entity);
    boolean delete(String ID);
    
    
    
}
