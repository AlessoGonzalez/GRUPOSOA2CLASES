/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quinto;

/**
 *
 * @author jespi
 */
public class Quinto {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
